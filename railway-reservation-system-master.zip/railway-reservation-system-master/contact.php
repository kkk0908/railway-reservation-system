<html lang="en">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
</head>
<body>
<div class="container">
<div class="row">
<div class="col align-self-center custom1">
<!--<div class="jumbotron">-->
<div class="row">
  <div class="col col-md-3">
<a href="https://en.wikipedia.org/wiki/WhatsApp" class="thumbnail"><i class="fa fa-whatsapp fa-4x" aria-hidden="true"></i></a>
<ul><li>+918590210346</li><li>+918714446494</li></ul></div>
<div class="col-md-3">
  <a href="https://en.wikipedia.org/wiki/LinkedIn" class="thumbnail"><i class="fa fa-linkedin fa-4x" aria-hidden="true"></i></a>
<ul><li>shanikumar1b01b6127</li></ul>
</div>
<div class="col-md-3">
  <a href="https://en.wikipedia.org/wiki/Email" class="thumbnail"><i class="fa fa-envelope-o fa-4x" aria-hidden="true"></i></a>
<ul><li>shani.pathak98@gmail.com</li><li>ashishvermag96@gmail.com</li><li>ctpmukashi@gmail.com</li><li>contact2satishpatna@gmail.com</li></ul>
</div>
<div class="col-md-3">
  <a style="" href="https://en.wikipedia.org/wiki/Facebook" class="thumbnail"><i class="fa fa-facebook-square fa-4x" aria-hidden="true"></i></a>
<ul><li>shanikumar.pathak.7</li> <li>kumar.satish.5602</li><ul></br></br></br></br></br></br></br></br></br></div>
</div></div></div>
</div>
</body>
</html>
