<html lang="en">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
<style>
h3 {text-align: center;
    }
.custom5{

  background-color: silver;
}
</style>
</head>
<body>
  <div class="container">
  <div class="row">
  <div class="col align-self-center custom5"><h3 style="color:blue">Songs</h3>
 <strong style="color:blue">HollyWood</strong><br>
<!--<div class="col-md-3">-->
<div class="row">
  <div class="col-md-3">
    <a href="E:\videos\favourite\english\The Chainsmokers - Closer (Lyric) ft. Halsey.mp4" class="thumbnail"><i class="fa fa-film" aria-hidden="true"></i> The Chainsmokers-Closer
<video width="250" height="200"><source src="E:\videos\favourite\english\The Chainsmokers - Closer (Lyric) ft. Halsey.mp4" type="video/mp4"></video></a></div>
  <div class="col-md-3">
    <a href="E:\videos\favourite\english\Enrique.mp4" class="thumbnail"><i class="fa fa-film" aria-hidden="true"> Enrique</i>
<video width="250" height="200"><source src="E:\videos\favourite\english\Enrique.mp4" type="video/mp4"></video></a></div>
  <div class="col-md-3">
  <a href="E:\videos\favourite\english\TaylorSwift.mp4" class="thumbnail"><i class="fa fa-film" aria-hidden="true"> Taylor Swift-Love Story_HIGH</i>
<video width="250" height="200"><source src="E:\videos\favourite\english\TaylorSwift.mp4" type="video/mp4"></video></a></div>
<div class="col-md-3">
<a href="E:\videos\favourite\english\faded (2).mp4" class="thumbnail"><i class="fa fa-film" aria-hidden="true"> Faded</i>
<video width="250" height="200"><source src="E:\videos\favourite\english\faded (2).mp4" type="video/mp4"></video></a></div>
</div>
<div class="row">
  <div class="col-md-3">
    <a href="E:\videos\favourite\english\The Chainsmokers - Don't Let Me Down ft. Daya.mp4" class="thumbnail"><i class="fa fa-film" aria-hidden="true"></i> The Chainsmokers-Don't Let Me Down
<video width="250" height="200"><source src="E:\videos\favourite\english\The Chainsmokers - Don't Let Me Down ft. Daya.mp4" type="video/mp4">"</video></a></div>
  <div class="col-md-3">
    <a href="E:\videos\favourite\english\Enrique Iglesias - Bailando (English Version) ft Sean Paul, Descemer Bueno, Gente De Zona.mp4" class="thumbnail"><i class="fa fa-film" aria-hidden="true"> Enrique Iglesias</i>
<video width="250" height="200"><source src="E:\videos\favourite\english\Enrique Iglesias - Bailando (English Version) ft Sean Paul, Descemer Bueno, Gente De Zona.mp4" type="video/mp4">"</video></a></div>
  <div class="col-md-3">
  <a href="E:\videos\favourite\english\Shape Of You.mp4" class="thumbnail"><i class="fa fa-film" aria-hidden="true"> Shape Of You</i>
<video width="250" height="200"><source src="E:\videos\favourite\english\Shape Of You.mp4" type="video/mp4"></video></a></div>
<div class="col-md-3">
<a href="E:\videos\favourite\english\Love Me Like You.mp4" class="thumbnail"><i class="fa fa-film" aria-hidden="true"> Love Me Like You </i>
<video width="250" height="200"><source src="E:\videos\favourite\english\Love Me Like You.mp4" type="video/mp4"></video></a></div>
</div>
<br><strong style="color:blue;">BollyWood</strong><br>
<div class="row">
<div class="col-md-3">
    <a href="D:\html\Html5\raske.mp4" class="thumbnail"><i class="fa fa-film" aria-hidden="true"> Mere Rashke</i>
    <video width="250" height="200"><source src="D:\html\Html5\raske.mp4" type="video/mp4"></video></a>
</div>
<div class="col-md-3">
      <a href="E:\videos\favourite\Zaroori Tha.mp4" class="thumbnail"><i class="fa fa-film" aria-hidden="true"> Zarooro Tha</i>
      <video width="250" height="200"><source src="E:\videos\favourite\Zaroori Tha.mp4" type="video/mp4"></video></a>
</div>
<div class="col-md-3">
      <a href="E:\videos\favourite\Channa Mereya.mp4" class="thumbnail"><i class="fa fa-film" aria-hidden="true"> Channa Mereya</i>
      <video width="250" height="200"><source src="E:\videos\favourite\Channa Mereya.mp4" type="video/mp4"></video></a>
</div>
<div class="col-md-3">
  <a href="E:\videos\favourite\Phir Bhi Tumko Chaahunga.mp4" class="thumbnail"><i class="fa fa-film" aria-hidden="true"> Phir Bhi Tumko Chaahunga</i>
  <video width="250" height="200"><source src="E:\videos\favourite\Phir Bhi Tumko Chaahunga.mp4" type="video/mp4"></video></a>
</div>
</div>

<div class="row">
<div class="col-md-3">
  <a href="E:\videos\favourite\Humsafar.mp4" class="thumbnail"><i class="fa fa-film" aria-hidden="true"> Humsafar</i>
  <video width="250" height="200"><source src="E:\videos\favourite\Humsafar.mp4" type="video/mp4"></video></a>
</div>
<div class="col-md-3">
  <a href="E:\videos\favourite\Lo Maan Liya.mp4" class="thumbnail"><i class="fa fa-film" aria-hidden="true"> Lo Maan Liya</i>
  <video width="250" height="200"><source src="E:\videos\favourite\Lo Maan Liya.mp4" type="video/mp4"></video></a>
</div>
<div class="col-md-3">
    <a href="E:\videos\favourite\Kabhi Jo Baadal.mp4" class="thumbnail"><i class="fa fa-film" aria-hidden="true"> Kabhi Jo Baadal</i>
    <video width="250" height="200"><source src="E:\videos\favourite\Kabhi Jo Baadal.mp4" type="video/mp4"></video></a>
  </div>
<div class="col-md-3">
       <a href="E:\videos\favourite\Kaun Tujhe.mp4" class="thumbnail"><i class="fa fa-film" aria-hidden="true"> Kaun Tujhe</i>
      <video width="250" height="200"><source src="E:\videos\favourite\Kaun Tujhe.mp4" type="video/mp4"></video></a>
</div>
</div>
<div class="row">
<div class="col-md-3">
  <a href="E:\videos\favourite\Dard Dilo Ke.mp4" class="thumbnail"><i class="fa fa-film" aria-hidden="true"> Dard Dilo Ke</i>
  <video width="250" height="200"><source src="E:\videos\favourite\Dard Dilo Ke.mp4" type="video/mp4"></video></a>
</div>
<div class="col-md-3">
  <a href="E:\videos\favourite\Afreen Afreen.mp4" class="thumbnail"><i class="fa fa-film" aria-hidden="true"> Afreen Afreen</i>
  <video width="250" height="200"><source src="E:\videos\favourite\Afreen Afreen.mp4" type="video/mp4"></video></a>
</div>
<div class="col-md-3">
    <a href="E:\videos\favourite\Hawayein.mp4" class="thumbnail"><i class="fa fa-film" aria-hidden="true"> Hawayein</i>
    <video width="250" height="200"><source src="E:\videos\favourite\Hawayein.mp4" type="video/mp4"></video></a>
  </div>
<div class="col-md-3">
       <a href="E:\videos\favourite\Sawan Aaya Hai.mp4" class="thumbnail"><i class="fa fa-film" aria-hidden="true"> Sawan Aaya Hai</i>
      <video width="250" height="200"><source src="E:\videos\favourite\Sawan Aaya Hai.mp4" type="video/mp4"></video></a>
</div>
</div>

</div>
</div>
</div>
</body>
</html>
<!--<video controls width="50%" height="240" autoplay loop>
  <source src="D:\html\Html5\raske.mp4" type="video/mp4">
 </video>
 <div class="col-md-4">
<a href="c2.jpg" class="thumbnail"><p>love</p><img src="c2.jpg"></a></div>-->
