<?php include("viewadmin.php"); ?>
<html>
<body>
<form action="route.php" method="post">
<table class="table table-striped table-hover table-condensed" style="background-color:lightblue;margin:10px;">
<tr><th style="text-align:center;">STATIONS:</th></tr>
<tr><th style="margin-left:100px;">Route 1</th></tr>
<tr><td>Patna</td></tr>
<tr><td>Asansole</td></tr>
<tr><td>Bhopal</td></tr>
<tr><td>Cuttack</td></tr>
<tr><td>Visakhapatnam</td></tr>
<tr><td>Chennai central</td></tr>
<tr><td>Ernakulam</td></tr>
<th style="margin-left:100px;">Route 2</th>
<tr><td>Gorkhpur</td></tr>
<tr><td>Lucknow</td></tr>
<tr><td>Kanpur Central</td></tr>
<tr><td>Bhopal</td></tr>
<tr><td>Chennail Central</td></tr>
<tr><td>Ernakulam</td></tr>
<tr><td>Alapuzha</td></tr>
<tr><td>Trivandrum</td></tr>

</table>
</body>
</html>
