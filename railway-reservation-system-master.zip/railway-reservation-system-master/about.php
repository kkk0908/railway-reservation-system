<html lang="en">
<head>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
<style>
.about
{
  background-color: silver;
}
</style>
<!--<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
--></head>
<body>
<div class="container">
<div class="row">
<div class="col align-self-center about">
<p>We all are the B.tech 3rd year <b><a href="https://en.wikipedia.org/wiki/Bachelor_of_Information_Technology">Information Technology</a>
</b> student of <b><a href="http://cucek.in/">Cochin University College Of Engineering Kuttanad.</a></b><br>
we would like to thanks <b>Jabir Sir</b> (Assistant Professor) and <b>Agath sir</b> (Assistant Professor) of our department, for there continuous support and help in designing of this website.
</p>
<div class="row">
<div class="col-md-3">
  <a href="skp.jpg" class="thumbnail"><p>Shani Kumar Pathak</p><img src="skp.jpg" class="img-circle  img-responsive" alt="love" width="300" height="200" ></a>
</div>
<div class="col-md-3">
  <a href="verma.jpg" class="thumbnail"><p>Ashish Verma</p><img src="verma.jpg" class="img-circle  img-responsive" width="210" height="100"></a>
</div>
<div class="col-md-3">
  <a href="ashique.jpg" class="thumbnail"><p>Md Ashique</p><img src="ashique.jpg" class="img-circle img-responsive"></a>
</div>

<div class="col-md-3">
  <a href="satish.jpg" class="thumbnail"><p>Satish Kumar</p><img src="satish.jpg" class="img-circle img-responsive"width="350" height="100"></a>
</div>
</div>
</div></div></div>
</body>
</html>
