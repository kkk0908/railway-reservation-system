<?php
session_start();
session_destroy();
header('location:http://localhost/myphp/railway/home.php');

?>
<html>
<body>
<!-- <a href="view.php">View</a> >
</body>
</html>
